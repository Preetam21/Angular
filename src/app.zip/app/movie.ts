export class Movie {
    constructor(title: string, release_date: string, id: number, poster_path: string, comment: string) { }
}